# Read & Speak — Android app

A starter Android app for reading English chapters from photos. Select a page image, let ML Kit OCR extract the text, then tap any recognized English word to hear it using Android Text-to-Speech. Choose British or American English, toggle slower speech, read the whole chapter aloud, look up an English definition, bookmark words, and save chapters on the device.

## Create a new GitHub repository and build the APK

1. On GitHub, create a **new repository** named `ReadSpeak` (do not reuse the old 5G Switcher repository).
2. Download and extract this ZIP on your phone or computer.
3. Open the extracted `ReadSpeak` folder. Upload **the contents inside this folder** to the top level of the new GitHub repository. The top level must contain `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and `.github/`.
   - Important: do not upload the outer `ReadSpeak` folder as an extra nested folder. The workflow file must end up at `.github/workflows/android.yml` in the repository root.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. The workflow **Build Read & Speak APK** should start automatically. You can also select it and press **Run workflow**.
6. When the run is green, open that run, scroll to **Artifacts**, and download `ReadSpeak-debug-apk`. Extract it to get `app-debug.apk`, then install it on your Android phone.

## Features in this starter

- Select a chapter photo from the phone.
- Extract printed English text with Google ML Kit Text Recognition.
- Tap a word to hear it immediately.
- Choose British English or American English voice (if installed on the phone).
- Slow speech toggle and read-the-whole-chapter button.
- Online English definition lookup.
- Save bookmarked words and chapters locally on the device.

## Important notes

- This ZIP contains Android source code and a GitHub Actions workflow, **not a prebuilt APK**.
- The workflow builds a debug APK automatically on GitHub Actions; it does not require Android Studio on your phone.
- Voice availability and exact accent depend on the Text-to-Speech engine and voices installed on the Android device. Install the desired English voices in Android Text-to-Speech settings if needed.
- OCR quality depends on image clarity, lighting, and printed text. Check the extracted text for mistakes.
- Dictionary definitions require internet access. The selected word is sent to the Free Dictionary API; chapter photos and saved text are not uploaded by this app.
